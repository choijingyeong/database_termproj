<?php
$license = $_GET['license'];
include "include\session.php";
include "include\dbConnect.php";

$today = date("y/m/d");
$start = $_GET['start'];
$end = $_GET['end'];
$cno = $_SESSION['ses_usercno'];

# 반납하기
# step1) prev에 넣기 (carmodel에서 결제정보 가져와서)
# 현재 반납하는 렌트카의 정보를 불러와 반납일을 오늘로 설정한 후 previous rental 테이블에 값을 insert하였다.
$sql = "
INSERT INTO PREVIOUSRENTAL (LICENSEPLATENO, DATERENTED, DATERETURNED, PAYMENT, CNO)
SELECT rc.LICENSEPLATENO, rc.DATERENTED, TRUNC(SYSDATE), cm.RENTRATEPERDAY * (TRUNC(SYSDATE) - rc.daterented + 1), rc.cno
FROM carmodel cm
JOIN rentcar rc ON cm.MODELNAME = rc.MODELNAME
WHERE rc.licenseplateno = '$license' and rc.returndate = '$end' and rc.daterented = '$start'
";
$sql = $conn->prepare($sql);
$sql->execute();

# step2) rentcar에서 대여정보들 null로 업데이트 - 즉 대여내역삭제
$sql = "update rentcar set daterented=null, returndate=null, cno=null WHERE licenseplateno = '$license' and
returndate = '$end' and daterented = '$start'";
$sql = $conn->prepare($sql);
$sql->execute();

# step3) 메일 전송 위한 유저 정보 및 대여 정보 불러오기
$sql = "
SELECT pr.LICENSEPLATENO, pr.DATERENTED, pr.datereturned, pr.payment, rc.modelname, cm.name, cm.email
FROM previousrental pr
JOIN rentcar rc ON pr.licenseplateno = rc.licenseplateno
join customer cm on pr.cno = cm.cno
where pr.licenseplateno = '$license' AND
cm.cno = '$cno' and
pr.daterented = '$start'";
$sql = $conn->prepare($sql);
$sql->execute();
$data = $sql->fetch(PDO::FETCH_BOTH);

# step4) PHP Mailer를 통해 메일 전송
use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\SMTP;

  require 'PHPMailer/src/Exception.php';
  require 'PHPMailer/src/PHPMailer.php';
  require 'PHPMailer/src/SMTP.php';

  $carnum = $data[0];
  $startdate = $data[1];
  $enddate = $data[2];
  $prize = $data[3];
  $carmodel = $data[4];
  $username = $data[5];
  $email = $data[6];

  $tmp = 'isnull';
  if($tmp != null) {
    $mail = new PHPMailer( true );
    $mail->isSMTP();
    $mail->SMTPDebug   = SMTP::DEBUG_SERVER;
    $mail->Host        = 'smtp.gmail.com';
    $mail->SMTPOptions = array(
      'ssl' => array(
          'verify_peer' => false,
          'verify_peer_name' => false,
          'allow_self_signed' => true
      )
    );
    $mail->SMTPDebug = 1;
    $mail->SMTPAuth    = true;
    $mail->Username    = 'jingyeongchoi0515@gmail.com';
    $mail->Password    = 'vhdrfbntyzrvhxje';
    $mail->CharSet     = "utf-8";
    $mail->SMTPSecure  = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port        = 465;
    $mail->Mailer      = 'smtp';
    $mail->setFrom( 'jingyeongchoi0515@gmail.com', '관리자' );
    $mail->addAddress( $email, $username."님" );  //  받는 사람의 이메일
    $mail->isHTML( true );
    $mail->Subject     = '[다함께 차차] '.$username.'님 반납이 완료되었습니다.';
    $mail->Body        = 
      '<h4>' . $username.'님</h4><br>
      차종 : ' . $carmodel .'<br>
      차 번호: ' . $carnum . '<br>
      기간 : ' . $startdate . ' - ' . $enddate . '<br>
      가격 : ' . $prize . '<br>
      <h4>반납 처리 완료되었습니다.</h4>';
    if(!$mail->send()) {
      # 전송 실패 시
      echo 'MailError: '.$mail->ErrorInfo;
    } else {
        # 결과 화면 리로드
        echo ("<SCRIPT>
        alert('결제가 완료되었습니다.');
        location.href='page_rent.php?';
        </SCRIPT>");
    }
  }

exit;
?>