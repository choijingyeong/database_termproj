<?php

include "include\dbConnect.php";
include "include\session.php";

// 예약된 차들 중 대여 시작일이 오늘인 예약 내역을 대여 중으로 변경
$date = date("Y-m-d");
$sql = 
    "select licenseplateno, startdate, enddate, cno
    from reservation
    where startdate = TRUNC(SYSDATE)";
    
$tmp = $conn->prepare($sql);
$tmp->execute();
$data = $tmp->fetch(PDO::FETCH_BOTH);
// 대여 시작일이 오늘인 예약이 있는 경우에만 아래 문장을 실행함
if($data != '') {
    $license = $data[0];
    $start = $data[1];
    $end = $data[2];
    $cno = $data[3];

    $sql = "update rentcar set daterented='$start', returndate='$end', cno='$cno' WHERE licenseplateno = '$license'";
    $tmp = $conn->prepare($sql);
    $tmp->execute();

    $sql = "delete from reservation where licenseplateno='$license' and startdate='$start' and enddate='$end'";
    $tmp = $conn->prepare($sql);
    $tmp->execute();
    // 예약 목록에서 해당 내역 삭제 및 rentcar 테이블에 정보 추가

}

# 현재 로그인 중인 회원이 대여 중인 렌트카들의 정보를 불러오는 문장을 실행함
$sql = "SELECT rc.Licenseplateno, cm.modelName, rc.daterented, rc.returndate, 
    cm.rentrateperday *(rc.returndate-rc.daterented)
    FROM rentcar rc
    JOIN carmodel cm ON rc.modelName = cm.modelName
    WHERE rc.cno = '{$_SESSION['ses_usercno']}'";
$stmt = $conn->prepare($sql);
$stmt->execute();
?>
<html>

<head>
    <style>
        @font-face {
            font-family: 'Pretendard Variable';
            font-weight: 45 920;
            font-style: normal;
            font-display: swap;
            src: local('Pretendard Variable'), url('./images/PretendardVariable.woff2') format('woff2-variations');
        }
    </style>
    <title>다함께 차차</title>

</head>
<font size=5 style="font-family: Pretendard Variable"><b> 다함께 차차 - 대여 내역 </font></b><br>
<?php

echo ('
<header>
    <nav id="navBar">
        <div class="navBarCon">
            <div class="navBarItem">
                <ul>
                    <a href="/Termproject/main_logined.php">
                        <li>홈으로</li>
                    </a>
                </ul>
            </div>
        </div>
    </nav>
</header>
');
?>

<?php
if (isset($_POST['search'])) {

    $model = $_POST['search'];
    $sql = "SELECT rc.Licenseplateno, cm.modelName, rc.daterented, rc.returndate, 
    cm.rentrateperday *(rc.returndate-rc.daterented)
    FROM rentcar rc
    JOIN carmodel cm ON rc.modelName = cm.modelName
    WHERE rc.cno = '{$_SESSION['ses_usercno']}'and cm.modelname LIKE '%$model%'";
    // 예약 내역 조회 쿼리
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    // 결과 출력
}
?>
<!-- 테이블의 칼럼을 표시하기 위한 html문 -->
<table border=0 width=580 style='table-layout:fixed;'>
    <tr height=25 bgcolor='#eef0f4'>
        <td width=100 align=center>
            <font size=2 style="font-family: Pretendard Variable">
                <b>모델 이름</b>
            </font>
        </td>
        <td width=100 align=center>
            <font size=2 style="font-family: Pretendard Variable">
                <b>차 번호판</b>
            </font>
        </td>
        <td width=100 align=center>
            <font size=2 style="font-family: Pretendard Variable">
                <b>대여 시작 날짜</b>
            </font>
        </td>
        <td width=100 align=center>
            <font size=2 style="font-family: Pretendard Variable">
                <b>반납 및 결제 날짜</b>
            </font>
        </td>
        <td width=100 align=center>
            <font size=2 style="font-family: Pretendard Variable">
                <b>결제 예정 금액</b>
            </font>
        </td>
        <td width=150 align=center>
            <font size=2><b>결제하기</b></font>
        </td>
    </tr>

    <?php
    // 아래는 현재 대여 중인 자동차 정보에 대해 가져온 내용을 출력해주는 html문임
    while ($row2 = $stmt->fetch(PDO::FETCH_BOTH)) {
        ?>
        <!-- echo (" -->
        <tr>
            <td align=center>
                <font size=2 style=\"font-family: Pretendard Variable\">
                    <div>
                        <?= $row2[1] ?>
                    </div>
            </td>

            <td align=center>
                <font size=2 style=\"font-family: Pretendard Variable\">
                    <?= $row2[0] ?>
            </td>

            <td align=center>
                <font size=2 style=\"font-family: Pretendard Variable\">
                    <?= $row2[2] ?>
                </font>
                </a>
            </td>


            <td align=center>
                <font size=2 style=\"font-family: Pretendard Variable\">
                    <?= $row2[3] ?>
                </font>
            </td>
            <td align=center>
                <font size=2 style=\"font-family: Pretendard Variable\">
                    <?= $row2[4] ?>
                </font>
            </td>

            <td align="center">
                <a href="page_rent_delete.php?license=<?= $row2[0] ?>&start=<?= $row2[2] ?>&end=<?= $row2[3] ?>">
                    [결제하기]
                </a>
            </td>
        </tr>
        <tr height=1>
            <td bgcolor='#ffeef7'>
            </td>
        </tr>
        <?php
    }

    ?>
</table>
<form action="page_rent.php?" method="post">
    <table>
        <tr>
            <td align="center">

                <input type="text" name="search" size="15" style="font-family: Pretendard Variable"
                    placeholder="모델 이름 검색">
                <input type="submit" style="font-family: Pretendard Variable" value="검색">
            </td>
        </tr>
    </table>
</form>

<form action="page_rent.php">
    <input type="submit" style="font-family: Pretendard Variable" value="초기화">
</form>

</html>